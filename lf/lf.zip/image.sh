#!/usr/bin/env bash
readonly ID_PREVIEW="preview"
main() {
	case "$1" in
		"clear")
			declare -p -A cmd=([action]=remove [identifier]="$ID_PREVIEW") \
				> "$FIFO_UEBERZUG"
			;;
		"draw")
			declare -p -A cmd=([action]=add [identifier]="$ID_PREVIEW" \
				[x]="$3" [y]="$4" [max_width]="$5" [max_height]="$6" \
				[path]="$2") > "$FIFO_UEBERZUG"
			;;
		"*") echo "Unknown command: '$1', '$2'" ;;
	esac
}
main "$@"

